NFL Game Prediction Algorithm
Created by Thomas Allen

This is a Python-based NFL game prediction algorithm developed by Thomas Allen. The program uses live stats and custom logic to *GUESS* game outcomes. It includes a graphical interface and supports up-to-date data scraping to enhance accuracy.

---Designed for personal or demonstration use---

Ownership & Rights:
This project was created entirely by Thomas Allen. While it is not currently copyrighted or licensed, all code and logic within the algorithm are the original work of the author. Redistribution or commercial use is not permitted without explicit permission.